# PBLJ-5th-Experiment---Unit2-Wrapper-Classes-I-O-Stream-Practice-1

- Part a: Sum of Integers Using Autoboxing and Unboxing
- Part b: Serialization and Deserialization of a Student Object
- Part c: Menu-Based Employee Management System Using File Handling
